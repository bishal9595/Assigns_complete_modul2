import { Component } from "@angular/core";

@Component({

    selector:'add-emp',
   // template:'<h1>In Add Employee Component.....</h1>'
  templateUrl:'app.add.html'
  /*template:`Employee Id is {{empId}} <br/>
   Employee Name is {{empName}} <br/>
   Employee salary is {{empSalary}} <br/>
   
   {{addEmployee()}} `*/
})
export class AddEmployeeComponent
{
  empId:number;
  empId2:number;
  empName:string;
  empSalary:number;
  empId1:number;
  empName1:string;
  empDept1:string;
  empDept:string;
  empSalary1:number;
   emp:any[]=[{empId:1001,empName:"Rahul",empSalary:9000,empDept:"Java"},
            {empId:1002,empName:"Sachin",empSalary:19000,empDept:"OraApps"},
            {empId:1003,empName:"Vikash",empSalary:29000,empDept:"BI"}];
   
  addEmployee():any{
    var emp:any[]=[];
      this.emp.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDept:this.empDept});
      console.log("employee added"+this.emp);
      //alert("Employee added"+this.empId+" "+this.empName+" "+this.empSalary);
     
  }
  deleteEmployee(data:number):any
  {
     
      this.emp.splice(data,1);
        alert("Delete..."+data);
  }
  updateEmployee():any
  {
     
      for(let data of this.emp)
      {
        if(this.empId2==data.empId)
        {
          data.empName=this.empName1;
          data.empDept=this.empDept1;
          data.empId=this.empId1;
          data.empSalary=this.empSalary1;
          alert("updated");
          break;
          
        }
      }
  }
  updateEmployee1(data:number):any
  {

       this.empId1=this.emp[data].empId;
       this.empId2=this.emp[data].empId;
        this.empDept1=this.emp[data].empDept;
       this.empName1=this.emp[data].empName;
       this.empSalary1=this.emp[data].empSalary;

  }

}