import { Component } from "@angular/core";



@Component({

    selector:'show-emp',
    templateUrl:'app.show.html'
})
export class ShowEmployeeComponent
{

}