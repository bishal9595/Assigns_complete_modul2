import { Component,OnInit } from "@angular/core";
import {EmployeeService} from './app.bookservice';
@Component
({
    selector:'show-book',
    templateUrl:'showbook.html'
})

export class ShowbookComponent implements OnInit
{

constructor(private service:EmployeeService)
{

}


empAll:any[]=[];

ngOnInit()
{
    this.service.getAllEmployee().subscribe((data:any)=>this.empAll=data);
}
deleteEmployee(data:number):any{
       
    this.empAll.splice(data,1);
}

}